package com.huochang.yard.util

import com.huochang.yard.data.model.Salary
import com.huochang.yard.data.model.YardRecord

/** Pure calculation helpers shared by the repository and the UI layer. */

fun recordCars(counts: Map<String, Int>): Int =
    counts.values.fold(0) { acc, v -> acc + (v ?: 0) }

fun recordMoney(counts: Map<String, Int>, prices: Map<String, Double>): Double =
    counts.entries.fold(0.0) { acc, (id, count) -> acc + (count ?: 0) * (prices[id] ?: 0.0) }

/** Build a quick lookup map typeId -> price from a list of work types. */
fun priceMap(types: List<com.huochang.yard.data.model.WorkType>): Map<String, Double> =
    types.associate { it.id to it.price }

fun totalCars(records: List<YardRecord>): Int =
    records.fold(0) { acc, r -> acc + recordCars(r.counts) }

fun totalMoney(records: List<YardRecord>, prices: Map<String, Double>): Double =
    records.fold(0.0) { acc, r -> acc + recordMoney(r.counts, prices) }

// ---- Formatting helpers ----

/** Format money amount for display. Hides value if hideAmt is true. */
fun formatMoney(amount: Double, hideAmt: Boolean = false): String =
    if (hideAmt) "¥***" else "¥${"%.2f".format(amount)}"

/** Format car count for display. */
fun formatCount(count: Int): String = count.toString()

/** Estimate monthly salary from piece income + base salary components. */
fun calculateEstSalary(salary: Salary, pieceIncome: Double, workDays: Int): Double =
    pieceIncome + salary.base + salary.meal + (salary.night * workDays / 26.0) + salary.bonus - salary.deduct

// ---- Java Time extensions for ReportScreen ----

import java.time.LocalDate
import java.time.format.DateTimeFormatter

/** Format a LocalDate as "YYYY-MM" month string. */
fun LocalDate.formatMonth(): String = this.format(DateTimeFormatter.ofPattern("yyyy-MM"))
