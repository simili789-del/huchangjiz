package com.huochang.yard.ui.today

import android.app.Application
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.awaitPointerEventScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.huochang.yard.data.YardRepository
import com.huochang.yard.data.model.SHIFT_DAY
import com.huochang.yard.data.model.SHIFT_NIGHT
import com.huochang.yard.data.model.WorkType
import com.huochang.yard.data.model.YardRecord
import com.huochang.yard.ui.BaseYardViewModel
import com.huochang.yard.ui.components.*
import com.huochang.yard.ui.theme.*
import com.huochang.yard.util.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.max

class TodayViewModel(application: Application) : BaseYardViewModel(application) {

    data class TodayForm(
        val date: String = todayStr(),
        val person: String = "",
        val car: String = ""
    )

    data class TodayUiState(
        val date: String,
        val person: String,
        val car: String,
        val workTypes: List<WorkType> = emptyList(),
        val counts: Map<String, Int> = emptyMap(),
        val todayRecords: List<YardRecord> = emptyList(),
        val todayCars: Int = 0,
        val todayIncome: Double = 0.0,
        val hideAmt: Boolean = false,
        val dayGoal: Int = 100,
        val justSaved: Boolean = false
    )

    private val _form = MutableStateFlow(TodayForm())
    val form: StateFlow<TodayForm> = _form.asStateFlow()

    private val _counts = MutableStateFlow(emptyMap<String, Int>())
    val counts: StateFlow<Map<String, Int>> = _counts.asStateFlow()

    fun setDate(d: String) = _form.update { it.copy(date = d) }
    fun setPerson(p: String) = _form.update { it.copy(person = p) }
    fun setCar(c: String) = _form.update { it.copy(car = c) }

    fun updateCount(typeId: String, delta: Int) {
        _counts.update { counts ->
            val current = counts[typeId] ?: 0
            val next = max(0, current + delta)
            if (next == 0) counts - typeId else counts + (typeId to next)
        }
    }

    suspend fun saveRecord() {
        val f = _form.value
        val c = _counts.value
        if (c.isEmpty()) return
        repo.saveRecord(
            YardRepository.SaveRequest(
                date = f.date, name = f.person.ifBlank { "未命名" },
                car = f.car, shift = SHIFT_DAY, counts = c, note = ""
            )
        )
        _counts.value = emptyMap()
    }

    fun deleteRecord(record: YardRecord) {
        viewModelScope.launch { repo.deleteRecord(record.id) }
    }

    val uiState: StateFlow<TodayUiState> = combine(
        _form, _counts, repo.workTypes, repo.records, repo.config
    ) { form, counts, types, records, config ->
        val todayRecords = records.filter { it.date == form.date }
        val prices = priceMap(types)
        TodayUiState(
            date = form.date,
            person = form.person,
            car = form.car,
            workTypes = types,
            counts = counts,
            todayRecords = todayRecords,
            todayCars = todayRecords.sumOf { recordCars(it.counts) },
            todayIncome = todayRecords.sumOf { recordMoney(it.counts, prices) },
            hideAmt = config.hideAmt,
            dayGoal = config.dayGoal
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TodayUiState(date = todayStr()))
}

@Composable
fun TodayScreen(
    viewModel: TodayViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var showSavedAnim by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (showSavedAnim) 1.1f else 1f, animationSpec = keyframes {
        this.durationMillis = 300
    }, label = "saveScale")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 顶部输入栏
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DateField(
                            value = uiState.date,
                            onValueChange = viewModel::setDate,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = uiState.person,
                            onValueChange = viewModel::setPerson,
                            label = { Text("记账人") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = uiState.car,
                        onValueChange = viewModel::setCar,
                        label = { Text("车号/备注") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // 今日统计
        item {
            Card {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("今日车数", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        Text(formatCount(uiState.todayCars), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("今日计件", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        Text(formatMoney(uiState.todayIncome, uiState.hideAmt), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Green)
                    }
                }
                // 进度条
                val progress = (uiState.todayCars.toFloat() / max(1, uiState.dayGoal)).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                )
                Text("目标: ${uiState.dayGoal}车",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(top = 4.dp))
            }
        }

        // 快捷记账列表
        item {
            SectionTitle("快捷记账")
        }

        items(uiState.workTypes) { type ->
            val count = uiState.counts[type.id] ?: 0
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TypeDot(type.color)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(type.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("¥${type.price}/车", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.updateCount(type.id, -1) },
                            enabled = count > 0
                        ) {
                            Icon(Icons.Filled.Remove, contentDescription = "减少")
                        }
                        Text("$count", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        IconButton(
                            onClick = { viewModel.updateCount(type.id, 1) }
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = "增加")
                        }
                    }
                }
            }
        }

        // 保存按钮
        item {
            val hasCounts = uiState.counts.values.any { it > 0 }
            Button(
                onClick = {
                    scope.launch { viewModel.saveRecord(); showSavedAnim = true; delay(500); showSavedAnim = false }
                },
                enabled = hasCounts,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .scale(scale),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("保存记录", fontSize = 16.sp)
            }
        }

        // 今日已记列表
        item {
            SectionTitle("今日已记")
        }

        if (uiState.todayRecords.isEmpty()) {
            item {
                Text("暂无记录", color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(8.dp))
            }
        } else {
            items(uiState.todayRecords) { record ->
                // 从 counts 中找出主要类型名
                val primaryTypeId = record.counts.maxByOrNull { it.value }?.key ?: ""
                val typeName = uiState.workTypes.find { it.id == primaryTypeId }?.name ?: "作业"
                val cars = recordCars(record.counts)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(Unit) {
                            detectTapGestures(onDoubleTap = {
                                // 双击清零（预留功能）
                            })
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            ShiftTag(record.shift)
                            Spacer(Modifier.height(4.dp))
                            Text("$typeName · ${cars}车", fontWeight = FontWeight.Bold)
                            Text("${record.name} · ${record.car.ifBlank { "无车号" }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                        Text(formatMoney(recordMoney(record.counts, priceMap(uiState.workTypes)), uiState.hideAmt),
                            fontWeight = FontWeight.Bold, color = Green)
                        TextButton(
                            onClick = {
                                viewModel.deleteRecord(record)
                                Toast.makeText(context, "已删除", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Text("删除", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
        }
        item { Spacer(Modifier.height(80.dp)) }
    }
}
