package com.huochang.yard.ui.today

import android.app.Application
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.awaitPointerEventScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.huochang.yard.data.YardRepository
import com.huochang.yard.data.model.SHIFT_DAY
import com.huochang.yard.data.model.SHIFT_NIGHT
import com.huochang.yard.data.model.WorkType
import com.huochang.yard.data.model.YardRecord
import com.huochang.yard.ui.BaseYardViewModel
import com.huochang.yard.ui.components.*
import com.huochang.yard.ui.theme.*
import com.huochang.yard.util.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.max

@Composable
fun TodayScreen(
    viewModel: TodayViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 顶部筛选区
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DateField(
                            value = uiState.date,
                            onValueChange = viewModel::setDate,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = uiState.person,
                            onValueChange = viewModel::setPerson,
                            label = { Text("记账人") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = uiState.car,
                        onValueChange = viewModel::setCar,
                        label = { Text("车号/备注") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // 今日统计卡片
        item {
            Card {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("今日车数", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        Text(formatCount(uiState.todayCars), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("今日计件", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        Text(formatMoney(uiState.todayIncome, uiState.hideAmt), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Green)
                    }
                }
            }
        }

        // 作业类型列表
        item {
            SectionTitle("快捷记账")
        }

        items(uiState.workTypes) { type ->
            val count = uiState.counts[type.id] ?: 0
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(type.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("¥${type.price}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.updateCount(type.id, -1) },
                            enabled = count > 0
                        ) {
                            Icon(Icons.Filled.Remove, contentDescription = "减少")
                        }
                        Text("$count", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        IconButton(
                            onClick = { viewModel.updateCount(type.id, 1) }
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = "增加")
                        }
                    }
                }
            }
        }

        // 今日记录快捷查看与管理
        item {
            SectionTitle("今日已记")
        }

        if (uiState.todayRecords.isEmpty()) {
            item {
                Text("暂无记录", color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(8.dp))
            }
        } else {
            items(uiState.todayRecords) { record ->
                val typeName = uiState.workTypes.find { it.id == record.typeId }?.name ?: "未知"
                Card(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("$typeName · ${record.cars}车", fontWeight = FontWeight.Bold)
                            Text("${record.person} · ${record.car.ifBlank { "无车号" }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                        TextButton(
                            onClick = {
                                viewModel.deleteRecord(record)
                                Toast.makeText(context, "已删除", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Text("删除", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}