package com.huochang.yard.ui.components

import android.app.DatePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.util.Calendar

// 1. 全局公开的日期选择框（删除了 private，任何 Screen 均可直接调用）
@Composable
fun DateField(
    value: String, 
    onValueChange: (String) -> Unit, 
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cal = Calendar.getInstance()
    value.split("-").let { 
        if (it.size == 3) {
            runCatching { cal.set(it[0].toInt(), it[1].toInt() - 1, it[2].toInt()) }
        }
    }
    
    val dialog = DatePickerDialog(
        context,
        { _, y, m, d -> onValueChange("%04d-%02d-%02d".format(y, m + 1, d)) },
        cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
    )

    Box(modifier = modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            trailingIcon = { Icon(Icons.Filled.DateRange, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                focusedBorderColor = MaterialTheme.colorScheme.primary
            )
        )
        Box(
            modifier = Modifier
                .matchParentSize()
                .clickable { dialog.show() }
        )
    }
}

// 2. 全局公开的人员下拉框
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonDropdown(
    value: String,
    persons: List<String>,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val options = listOf("全部") + persons

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = if (value == "all") "全部" else value,
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            label = { Text("人员") },
            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { opt ->
                val key = if (opt == "全部") "all" else opt
                DropdownMenuItem(
                    text = { Text(opt) },
                    onClick = {
                        onValueChange(key)
                        expanded = false
                    }
                )
            }
        }
    }
}

// 3. 概要卡片（给 footer 赋予默认值 = {}，彻底解决“缺少参数 footer”报错）
@Composable
fun SummaryCard(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface,
    footer: @Composable () -> Unit = {} // 👈 默认空 lambda
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, style = MaterialTheme.typography.titleMedium, color = valueColor)
            footer()
        }
    }
}