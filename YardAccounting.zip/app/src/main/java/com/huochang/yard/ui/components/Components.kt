package com.huochang.yard.ui.components

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// 1. 日期选择框
@Composable
fun DateField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cal = java.util.Calendar.getInstance()
    value.split("-").let {
        if (it.size == 3) {
            runCatching { cal.set(it[0].toInt(), it[1].toInt() - 1, it[2].toInt()) }
        }
    }

    val dialog = DatePickerDialog(
        context,
        { _, y, m, d -> onValueChange("%04d-%02d-%02d".format(y, m + 1, d)) },
        cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.DAY_OF_MONTH)
    )

    Box(modifier = modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            trailingIcon = { Icon(Icons.Filled.DateRange, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                focusedBorderColor = MaterialTheme.colorScheme.primary
            )
        )
        Box(
            modifier = Modifier
                .matchParentSize()
                .clickable { dialog.show() }
        )
    }
}

// 2. 人员下拉框
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonDropdown(
    value: String,
    persons: List<String>,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val options = listOf("全部") + persons

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = if (value == "all") "全部" else value,
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            label = { Text("人员") },
            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { opt ->
                val key = if (opt == "全部") "all" else opt
                DropdownMenuItem(
                    text = { Text(opt) },
                    onClick = {
                        onValueChange(key)
                        expanded = false
                    }
                )
            }
        }
    }
}

// 3. 概要卡片
@Composable
fun SummaryCard(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface,
    footer: @Composable () -> Unit = {}
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, style = MaterialTheme.typography.titleMedium, color = valueColor)
            footer()
        }
    }
}

// 4. 区块标题
@Composable
fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(vertical = 4.dp)
    )
}

// 5. 分组卡片容器
@Composable
fun GroupedCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp), content = content)
    }
}

// 6. 表单行（标签 + 输入框）
@Composable
fun FormRow(label: String, content: @Composable () -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
        content()
    }
}

// 7. 类型颜色圆点
@Composable
fun TypeDot(color: String) {
    Box(
        modifier = Modifier
            .size(10.dp)
            .clip(CircleShape)
            .background(Color.fromHex(color))
    )
}

// 8. 记录卡片
@Composable
fun RecordCard(
    record: com.huochang.yard.data.model.YardRecord,
    types: List<com.huochang.yard.data.model.WorkType>,
    prices: Map<String, Double>,
    hideAmt: Boolean,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    showCheck: Boolean = false,
    checked: Boolean = false,
    onToggleCheck: (() -> Unit)? = null,
    showEdit: Boolean = true
) {
    val typeName = types.find { it.id == record.counts.keys.firstOrNull() }?.name ?: "作业"
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            if (showCheck && onToggleCheck != null) {
                Checkbox(checked = checked, onCheckedChange = { onToggleCheck() })
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("${record.date} · ${record.name}", fontWeight = FontWeight.Medium)
                Text("${record.car.ifBlank { "无车号" }} · ${if (record.shift == com.huochang.yard.data.model.SHIFT_NIGHT) "夜班" else "白班"}",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                Text(record.counts.entries.joinToString(", ") { "${it.key}=${it.value}车" },
                    style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(com.huochang.yard.util.formatMoney(com.huochang.yard.util.recordMoney(record.counts, prices), hideAmt),
                    fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (showEdit) {
                        IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Filled.Edit, contentDescription = "编辑", modifier = Modifier.size(16.dp))
                        }
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Delete, contentDescription = "删除", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

// 9. Dynamic Island 风格 Toast 提示
@Composable
fun DynamicIslandToast() {
    val toastState = rememberToastState()
    if (toastState.visible.value) {
        Surface(
            color = MaterialTheme.colorScheme.primary,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Text(toastState.message.value,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
        }
    }
}

// Toast 状态管理
data class ToastState(
    val visible: MutableState<Boolean> = mutableStateOf(false),
    val message: MutableState<String> = mutableStateOf(""),
    val actionLabel: MutableState<String> = mutableStateOf(""),
    val onAction: MutableState<(() -> Unit)?> = mutableStateOf(null)
)

@Composable
fun rememberToastState(): ToastState = remember { ToastState() }

// Toast 扩展函数
fun CoroutineScope.toast(message: String, actionLabel: String = "", onAction: (() -> Unit)? = null) {
    // 简化实现：实际项目中可替换为 SnackBar 或自定义 Toast
}

// 10. 筛选标签行
@Composable
fun FilterChipRow(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
    ) {
        options.forEach { (key, label) ->
            FilterChip(
                selected = (key == selected),
                onClick = { onSelect(key) },
                label = { Text(label) }
            )
        }
    }
}

// 11. 班次标签
@Composable
fun ShiftTag(shift: String) {
    val isNight = shift == com.huochang.yard.data.model.SHIFT_NIGHT
    Surface(
        color = if (isNight) com.huochang.yard.ui.theme.Indigo.copy(alpha = 0.15f) else com.huochang.yard.ui.theme.Orange.copy(alpha = 0.15f),
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(if (isNight) "夜班" else "白班",
            color = if (isNight) com.huochang.yard.ui.theme.Indigo else com.huochang.yard.ui.theme.Orange,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
    }
}
