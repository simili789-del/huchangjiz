package com.huochang.yard.ui.report

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.huochang.yard.data.model.YardRecord
import com.huochang.yard.ui.BaseYardViewModel
import com.huochang.yard.ui.components.*
import com.huochang.yard.ui.theme.*
import com.huochang.yard.util.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

class ReportViewModel(app: android.app.Application) : BaseYardViewModel(app) {
    private val _month = MutableStateFlow(LocalDate.now().formatMonth())
    private val _person = MutableStateFlow("all")

    val month: StateFlow<String> = _month.asStateFlow()
    val person: StateFlow<String> = _person.asStateFlow()

    fun setMonth(m: String) { _month.value = m }
    fun setPerson(p: String) { _person.value = p }

    val uiState: StateFlow<ReportUiState> = combine(
        repo.records, repo.workTypes, repo.profile, repo.salary,
        _month, _person
    ) { records, types, prof, sal, m, p ->
        val filtered = records.filter { it.date.startsWith(m) }
            .filter { p == "all" || it.person == p }

        val typeMap = types.associateBy { it.id }
        val pieceIncome = filtered.sumOf { (typeMap[it.typeId]?.price ?: 0.0) * it.cars }

        val workDays = filtered.map { it.date }.distinct().size
        val estSalary = calculateEstSalary(sal, pieceIncome, workDays)

        val dailyMap = filtered.groupBy { it.date.takeLast(2).toIntOrNull() ?: 1 }
            .mapValues { entry -> entry.value.sumOf { (typeMap[it.typeId]?.price ?: 0.0) * it.cars } }

        val daysInMonth = runCatching {
            val parts = m.split("-")
            java.time.YearMonth.of(parts[0].toInt(), parts[1].toInt()).lengthOfMonth()
        }.getOrDefault(31)

        val dailyList = (1..daysInMonth).map { day ->
            DailyIncome(day = day, income = dailyMap[day] ?: 0.0)
        }

        val typeSummary = filtered.groupBy { it.typeId }
            .map { (tid, recs) ->
                val name = typeMap[tid]?.name ?: "未知"
                val cars = recs.sumOf { it.cars }
                val price = typeMap[tid]?.price ?: 0.0
                TypeSummary(name, cars, price, cars * price)
            }.sortedByDescending { it.amount }

        val personSummary = filtered.groupBy { it.person }
            .map { (pName, recs) ->
                val cars = recs.sumOf { it.cars }
                val amt = recs.sumOf { (typeMap[it.typeId]?.price ?: 0.0) * it.cars }
                PersonSummary(pName, cars, amt)
            }.sortedByDescending { it.amount }

        val persons = records.map { it.person }.filter { it.isNotBlank() }.distinct()

        ReportUiState(
            month = m,
            person = p,
            pieceIncome = pieceIncome,
            estSalary = estSalary,
            workDays = workDays,
            dailyList = dailyList,
            typeSummary = typeSummary,
            personSummary = personSummary,
            persons = persons,
            hideAmt = prof.hideAmt
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ReportUiState())
}

data class DailyIncome(val day: Int, val income: Double)
data class TypeSummary(val name: String, val cars: Int, val price: Double, val amount: Double)
data class PersonSummary(val person: String, val cars: Int, val amount: Double)

data class ReportUiState(
    val month: String = "",
    val person: String = "all",
    val pieceIncome: Double = 0.0,
    val estSalary: Double = 0.0,
    val workDays: Int = 0,
    val dailyList: List<DailyIncome> = emptyList(),
    val typeSummary: List<TypeSummary> = emptyList(),
    val personSummary: List<PersonSummary> = emptyList(),
    val persons: List<String> = emptyList(),
    val hideAmt: Boolean = false
)

@Composable
fun ReportScreen(viewModel: ReportViewModel) {
    val ui by viewModel.uiState.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MonthField(
                    value = ui.month,
                    onValueChange = viewModel::setMonth,
                    modifier = Modifier.weight(1f)
                )
                PersonDropdown(
                    value = ui.person,
                    persons = ui.persons,
                    onValueChange = viewModel::setPerson,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SummaryCard(
                    modifier = Modifier.weight(1f),
                    label = "月度计件收入",
                    value = formatMoney(ui.pieceIncome, ui.hideAmt),
                    valueColor = Green
                )
                SummaryCard(
                    modifier = Modifier.weight(1f),
                    label = "预估总工资",
                    value = formatMoney(ui.estSalary, ui.hideAmt),
                    valueColor = primary
                )
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("每日计件趋势", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(16.dp))
                    BarChart(dailyList = ui.dailyList, hideAmt = ui.hideAmt)
                }
            }
        }

        item {
            SectionTitle("按作业类型汇总")
            if (ui.typeSummary.isEmpty()) {
                Text("暂无数据", color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(8.dp))
            } else {
                Card {
                    Column {
                        ui.typeSummary.forEach { t ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(t.name, fontWeight = FontWeight.Bold)
                                    Text("${t.cars}车 · 单价 ¥${t.price}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                }
                                Text(formatMoney(t.amount, ui.hideAmt), fontWeight = FontWeight.Bold, color = Green)
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        }

        item {
            SectionTitle("按人员汇总")
            if (ui.personSummary.isEmpty()) {
                Text("暂无数据", color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(8.dp))
            } else {
                Card {
                    Column {
                        ui.personSummary.forEach { p ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(p.person, fontWeight = FontWeight.Bold)
                                Text("${p.cars}车 · ${formatMoney(p.amount, ui.hideAmt)}", fontWeight = FontWeight.Bold)
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MonthField(value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        IconButton(onClick = {
            runCatching {
                val parts = value.split("-")
                val dt = LocalDate.of(parts[0].toInt(), parts[1].toInt(), 1).minusMonths(1)
                onValueChange(dt.formatMonth())
            }
        }) {
            Icon(Icons.Filled.ChevronLeft, contentDescription = "上月")
        }
        Text(value, fontWeight = FontWeight.Bold)
        IconButton(onClick = {
            runCatching {
                val parts = value.split("-")
                val dt = LocalDate.of(parts[0].toInt(), parts[1].toInt(), 1).plusMonths(1)
                onValueChange(dt.formatMonth())
            }
        }) {
            Icon(Icons.Filled.ChevronRight, contentDescription = "下月")
        }
    }
}

@Composable
private fun BarChart(dailyList: List<DailyIncome>, hideAmt: Boolean) {
    val maxIncome = dailyList.maxOfOrNull { it.income }?.takeIf { it > 0 } ?: 100.0
    val primaryColor = MaterialTheme.colorScheme.primary

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth().height(140.dp)
    ) {
        items(dailyList) { item ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxHeight(),
                verticalArrangement = Arrangement.Bottom
            ) {
                val heightRatio = (item.income / maxIncome).toFloat().coerceIn(0f, 1f)
                Box(
                    modifier = Modifier
                        .width(16.dp)
                        .weight(1f, fill = false),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Canvas(modifier = Modifier.fillMaxWidth().fillMaxHeight(heightRatio)) {
                        drawRect(color = primaryColor)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text("${item.day}日", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
            }
        }
    }
}